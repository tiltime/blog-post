# blog-post
MAQE assignment
Build with Next.js

## Getting Started

### Installing
```
npm install
```
To run application

```
npm run dev
```